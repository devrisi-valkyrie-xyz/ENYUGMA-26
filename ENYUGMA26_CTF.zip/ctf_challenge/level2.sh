#!/bin/bash

PAYLOAD="level2.zip"

read -sp "Enter password to proceed: " pass
echo

unzip -t -P "$pass" "$PAYLOAD" >/dev/null 2>&1

if [ $? -eq 0 ]; then
    clear
    figlet "CONGRATS"
    figlet "LEVEL 2 UNLOCKED"
    echo
    echo "Look beyond what is visible."
    echo

    unzip -o -P "$pass" "$PAYLOAD" >/dev/null 2>&1
    echo "Level 2 files extracted."
    

else
    clear
    figlet "WRONG"
    figlet "DIRECTION"
    echo

    
    xdg-open image1.jpeg >/dev/null 2>&1 &

    for i in {1..50}; do echo -n "😂"; done
    echo
    echo
    echo "You are going in the wrong direction."
fi
