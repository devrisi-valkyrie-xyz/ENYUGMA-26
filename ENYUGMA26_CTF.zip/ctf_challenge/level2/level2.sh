#!/bin/bash

read -sp "Enter password: " pass
echo

if [ "$pass" = "sh4d0w_w4tcher" ]; then
    clear
    figlet "CONGRATS"
    figlet "ENTER THE LEVEL 2"
    xdg-open image2.jpeg >/dev/null 2>&1

elif [ "$pass" = "sh4d0w_f0ll0wer" ]; then
    clear
    figlet "YOU ARE"
    figlet "GOING IN"
    figlet "WRONG DIRECTION"
    echo
    # 50 laughing emojis 😂
    for i in {1..5}; do
        echo "😂😂😂😂😂😂😂😂😂😂"
    done

else
    echo "Wrong password"
fi
